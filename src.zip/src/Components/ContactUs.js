import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './ContactUs.css';
import Header from './Header';
import Footer from './Footer';

export default class ContactUs extends Component {

    render() {

        return (

            <>

                <Header></Header>

                <div class="container">

                    <div class="contact-section">

                        {/* <form class="form-inline md-form mr-auto mb-3">

  <input class="form-control mr-sm-2" type="text" placeholder="Enter ISIN Number" aria-label="Search"></input>

  <button class="btn btn-accent" type="submit">Search</button>

</form> */}

                        <h2 class="ct-section-head">CONTACT US</h2>

                        <div class="row contact-fields">

                            <div class="col-md-8 left-form">

                                <form method="post" action="">

                                    <div class="form-group">

                                        <label class="sr-only" for="fname">First Name *</label>

                                        <input class="required form-control see" id="fname" name="fname" placeholder="First Name&nbsp;*" type="text" required></input>

                                    </div>

                                    <div class="form-group">

                                        <label class="sr-only" for="lname">Last Name *</label>

                                        <input class="required form-control" id="lname" name="lname" placeholder="Last Name&nbsp;*" type="text" required></input>

                                    </div>

                                    <div class="form-group">

                                        <label class="sr-only" for="contactEmail">Email *</label>

                                        <input class="required form-control h5-email" id="contactEmail" name="contactEmail" placeholder="Email&nbsp;*" type="text" required></input>

                                    </div>

                                    <div class="form-group">

                                        <label class="sr-only" for="contactPhone">Phone *</label>

                                        <input class="required form-control h5-phone" id="contactPhone" name="contactPhone" placeholder="Phone&nbsp;*" type="text" required></input>

                                    </div>

                                    <div class="form-group">

                                        <label class="sr-only" for="comment">Type your message here</label>

                                        <textarea class="required form-control" id="comment" name="comment" placeholder="Type your message here&nbsp;*" rows="2" required></textarea>

                                    </div>

                                    <button class="btn btn-accent" type="submit">Submit</button>

                                </form>

                            </div>

                            <div class="col-md-4 contact-info">

                                <div class="info">

                                    <div class="phone">

                                        <h2>Call</h2>

                                        <a href="#">+91 9876543210</a>

                                    </div>

                                    <div class="email">

                                        <h2>Email</h2>

                                        <a href="#">wrm@info.com</a>

                                    </div>

                                    <div class="location">

                                        <h2>Visit</h2>

                                        <a href="#">SIPCOT IT Park, Chennai</a>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                <Footer></Footer>

            </>

        )

    }

}