import React, { Component } from 'react'
import Header from './Header';
import Footer from './Footer';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import axios from 'axios';
import './AboutUs.css';

export default class AboutUs extends Component {

    render() {
       return (
           <>
                <Header></Header>

                    <div class="about-section">

                        <div className='about'>

                            <h1>Know us better</h1>




                            <h2>Wheelchair Request Management </h2>




                            <h3>Team 3</h3>




                            <p>
                                <br></br>
                            </p>


                        {/* </div><h2 style="text-align:center">Our Team</h2><div class="row"> */}

                        <div class="column">

                            <div class="card2 pro">

                                <div class="container">

                                    <h3>Amit Patil</h3>

                                    <p>AmitP11@hexaware.com</p>

                                </div>




                            </div>

                        </div>

                        <div class="column">

                            <div class="card2">

                                <div class="container">

                                    <h3>Talluri Shailaja</h3>

                                    <p>talluris@hexaware.com</p>

                                </div>

                            </div>




                        </div>




                        <div class="column">

                            <div class="card2">

                                <div class="container">

                                    <h3>Gandham Manimala</h3>

                                    <p>gandhamm@hexaware.com</p>

                                </div>

                            </div>

                        </div>

                        <div class="column">

                            <div class="card2">

                                <div class="container">

                                    <h3>Vijay Rangnath Salunkhe</h3>

                                    <p>vijayrangnaths@hexaware.com</p>
                                </div>




                            </div>




                        </div>




                        <div class="column">

                            <div class="card2">

                                <div class="container">

                                    <h3>Vineetha Palivela</h3>

                                    <p>vineethap@hexaware.com</p>




                                </div>




                            </div>




                        </div>




                    </div>
</div>

                    <Footer></Footer>

                </>
        )
    }
}