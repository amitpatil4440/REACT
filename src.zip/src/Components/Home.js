import React, { Component } from 'react';
import Header from './Header';
import Footer from './Footer';

import './Home.css'
import { Link } from 'react-router-dom';

export default class First extends Component {

 render() {

 return (<>
    <Header></Header>

 <div className='first'>

 <div className='second'>

 <h1>Wheelchair Request Management</h1>

 <p>Our Wheelchair Request Management allows passengers to request for wheelchairs at airport.<br></br>
Our staff accepts the request and provide them hassle-free travel experience.</p>

 {/* <a href="" class="hero-btn">Get Started</a> */}
 <Link to={"/PassengerLogin"} class="hero-btn">Get Started</Link>

 </div>

 </div>
 <Footer></Footer>
 </>

 )

 }

}