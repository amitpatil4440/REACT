import React, { Component } from 'react'

import './Footer.css';

export default class Footer extends Component {

    render() {

        return (

            <>

                <footer class="footer-section">

                    <div class="container">

                        <div class="footer-cta pt-5 pb-5">

                            <div class="row">

                                <div class="col-xl-4 col-md-4 mb-30">

                                    <div class="single-cta">

                                        <i class="fas fa-map-marker-alt"></i>

                                        <div class="cta-text">

                                            <h4>Find us</h4>

                                            <span>SIPCOT IT Park, Chennai</span>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-xl-4 col-md-4 mb-30">

                                    <div class="single-cta">

                                        <i class="fas fa-phone"></i>

                                        <div class="cta-text">

                                            <h4>Call us</h4>

                                            <span>+91 9876543210</span>

                                        </div>

                                    </div>

                                </div>

                                <div class="col-xl-4 col-md-4 mb-30">

                                    <div class="single-cta">

                                        <i class="far fa-envelope-open"></i>

                                        <div class="cta-text">

                                            <h4>Mail us</h4>

                                            <span>wrm@info.com</span>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div className='forfoot'>

                            <div class="footer-content pt-5 pb-5">

                                <div class="row">

                                    <div class="col-xl-4 col-lg-4 mb-50">

                                        <div class="footer-widget">

                                            <div class="footer-logo">

                                                <a href="#"><h4>Wheelchair Request Management</h4></a>

                                            </div>

                                            <div class="footer-text">

                                                <p>We provide hassle-free travel experience to our all passengers.</p>

                                            </div>

                                            {/* <div class="footer-social-icon">

<span>Follow us</span>

<a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>

<a href="#"><i class="fab fa-twitter twitter-bg"></i></a>

<a href="#"><i class="fab fa-google-plus-g google-bg"></i></a>

</div> */}

                                        </div>

                                    </div>

                                    <div class="col-xl-4 col-lg-4 col-md-6 mb-30 dog">

                                        <div class="footer-widget">

                                            <div class="footer-widget-heading cat">

                                                <h3>Useful Links</h3>

                                            </div>

                                            <ul>

                                                <li><a href="#">Home</a></li>

                                                <li><a href="#">about</a></li>

                                                <li><a href="#">services</a></li>

                                                <li><a href="#">portfolio</a></li>

                                                <li><a href="#">Contact</a></li>

                                                <li><a href="#">About us</a></li>

                                                <li><a href="#">Our Services</a></li>

                                                <li><a href="#">Expert Team</a></li>

                                                <li><a href="#">Contact us</a></li>

                                                <li><a href="#">Latest News</a></li>

                                            </ul>

                                        </div>

                                    </div>

                                </div>




                            </div>

                        </div>

                    </div>




                </footer>

            </>

        )

    }

}