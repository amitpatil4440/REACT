import React, { Component } from 'react'
import Header from '../Components/Header'
import '../Passenger/PassengerLogin.css'
import axios from 'axios';
export default class SupervisorLogin extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       email:'',
       password:'',
       emailerror:'',
      passworderror:''
    }
    this.submit=this.submit.bind(this);
      this.BtnSubmit=this.BtnSubmit.bind(this);
      this.handlechange=this.handlechange.bind(this);
  }
  submit()
    {
      console.log(this.state);
        let url="http://localhost:53678/api/Supervisor/login";
          
        axios.post(url,{
            // email:'user0@gmail.com',         
            // password:'ss' 
            email:this.state.email,         
            password:this.state.password
          }).then(response=>{
            if(response.data.email!=='')
            {
          //  alert(response.data.email);
            sessionStorage.setItem("email",JSON.stringify(response.data.email)); 
            window.location='/ViewSSRRequests';
            // sessionStorage.setItem("customer",JSON.stringify(Response.data));
            // window.location="/Home";}}).catch(e=>setLogin('Incorrect email or password'))       
            }
            else
            {
                alert("Username/password is Invalid");
            }
       }).catch(error=>{
            alert(error);
        });
    }
handlechange(object)
  {
      this.setState(object);
  }
   BtnSubmit()
{
    this.setState({
      emailerror:'',passworderror:''
    })
     if(this.Validate())
     {
        this.submit();
        
        alert("Login Successful");
        
     }
  
}
   Validate()
{
  
  if(!this.state.email.includes("@") && this.state.password.length<4)
  {
   this.setState({emailerror:'Invalid Email',passworderror:"Password length should be more than 4 character"});
  }
  else if(!this.state.email.includes("@"))
  {
    this.setState({emailerror:'Invalid Email'}); 
  }
  else if(this.state.password.length<4)
  {
  this.setState({passworderror:'Password length should be more than 4 character'}); 
  }
    
  else
    {
        return true;
    }
  }
  
  render() {
    return (
        <>
        <Header></Header>
      <div className='ccc'>
         <form>

  <div class="form-group">
    <label for="exampleInputEmail1">Supervisor Email</label>
    <input type="email" class="form-control" id="exampleInputEmail1" onChange={(e)=>this.handlechange({email:e.target.value})} aria-describedby="emailHelp" placeholder="Enter Email"></input>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1"> Password</label>
    <input type="password" class="form-control" onChange={(e)=>this.handlechange({password:e.target.value})} id="exampleInputPassword1" placeholder="Enter Password"></input>
  </div>
  <button onClick={this.BtnSubmit} class="btn btn-primary">Sign In </button>
</form> 
      </div>
      </>
    )
  }
}
