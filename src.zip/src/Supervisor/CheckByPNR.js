import React, { Component } from 'react'

export default class CheckByPNR extends Component {
    constructor(props) {
        super(props)
     
        this.state = {
          Check:[]
      
        }

        SearchByPNR()
        {
           
            let pnrNo=this.state.pnrNo;
            // console.log(policyType);
            let url="http://localhost:50450/api/User/GetPolicyByType/"+pnrNo;
            axios.get(url).then(resp=>{
        //  alert(resp.data);
                
                this.setState({
    
                    // Policies:resp.data
                    // policyId:resp.data.policyId,
                    // policyName:resp.data.policyName,
                    
                    Check:resp.data
                    
                });
               }).catch(error=>{
                console.warn(error);
            })
        }
        componentDidMount()
        {
            this.SearchByPNR();
        }
        handleChange(object)
        {
            this.setState(object);
    
        }
    

  render() {
    const {Check}=this.state;
    return (

        <>
      <div>


      </div>
      </>
    )
  }
}
