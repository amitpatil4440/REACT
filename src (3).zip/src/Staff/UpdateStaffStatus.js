import React, { Component } from 'react';
import '../Staff/GetDetails.css';
import Header from '../Components/Header'
import Footer from '../Components/Footer'
import axios from 'axios';
import { Link, useLoaderData, useParams, withRouter } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';

function UpdateStaffStatus() {

  const {staffId} = useParams();
  const [staffName, setStaffName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [availability, setAvailability] = useState('');
  const [workingStatus, setWorkingStatus] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [gateNo, setGateNo] = useState( );
  const [pnrNo, setPnrNo] = useState('');
  const [data, setData] = useState(null);


  useEffect(() => {

  async function loadData() {
try{
    const response = await axios.get(`http://localhost:53678/api/Staff/GetStaffById?StaffId=${staffId}`);
    const recievedData=response.data;

    setData(recievedData);
    setStaffName(recievedData.staffName);
    setEmail(recievedData.email);
    setPassword(recievedData.password);
    setAvailability(recievedData.availability);
    setWorkingStatus(recievedData.workingStatus);
    setContactNo(recievedData.contactNo);
    setGateNo(recievedData.gateNo);
    setPnrNo(recievedData.pnrNo);

  }
  catch (error){
    console.log(error);
  }
  }
    loadData();

  }, [staffId]);

  // const handleChange = (e) => {
  //   setData({ ...data, [e.target.name]: e.target.value });

  // };
///////////////////////////////////////
const handleSubmit= async (e)=>{
  e.preventDefault();
  try{
    console.log(staffId)
  await axios.put(`http://localhost:53678/api/Staff/StaffUpdate?StaffId=${staffId}`,{
    staffName,
    email,
    password,
    availability,
    workingStatus,
    contactNo,
    gateNo,
    pnrNo
  });
  console.log(staffId);
  console.log('Update Successful');
  alert('Update Successful');
  // window.location('/StaffAvailability')
  window.location = '/StaffDashboard';
}
  catch(error){
    console.log(error);
  }
};
  

    //////////////////////////////////////
  return (
    <>

      <Header></Header>
      <div className='xyz'>
        <div className='xyz1'>
          
            <form className='Form'>
              


              <div class="form-group">
                <label for="exampleInputEmail1">Staff Id</label>
                <input type="text" class="form-control"   value={staffId} onChange={(e) => staffId(e.target.value)} placeholder="Enter Staff Id" readOnly ></input>
              </div>
              <div class="form-group">
                <label htmlFor="exampleInputEmail1">Email </label>
                <input type="email" class="form-control"  value={email} onChange={(e) => setEmail(e.target.value)} placeholder="enter email" readOnly ></input>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputEmail1">Password </label>
                <input type="password" class="form-control"  value={password} onChange={(e) => setPassword(e.target.value)} placeholder="enter password" readOnly></input>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputPassword1">Staff Name</label>
                <input type="text" class="form-control"   value={staffName} onChange={(e) => setStaffName(e.target.value)} placeholder="Enter Name" readOnly></input>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputEmail1">Availability</label>
                <input type="text" class="form-control"   value={availability} onChange={(e) => setAvailability(e.target.value)} placeholder="Enter Availability"></input>
              </div>

              {/* <div class="form-group">

                <label htmlFor="exampleInputEmail1">Availability</label>
                <select onChange={(e) => setAvailability(e.target.value)} class="form-control">
                  <option name="default" style={{ color: 'grey' }}>Select an option</option>
                  <option name="available">Available</option>
                  <option name="assigned">Assigned</option>
                </select>
              </div> */}

              {/* <div class="form-group">
                <label htmlFor="exampleInputEmail1">Working Status</label>
                <input type="text" class="form-control"  value={workingStatus} onChange={(e) => setWorkingStatus(e.target.value)} placeholder="Enter Working Status"></input>
              </div> */}

              <div class="form-group">

                <label htmlFor="exampleInputEmail1">Working Status</label>
                <select onChange={(e) => setWorkingStatus(e.target.value)} class="form-control">
                  <option name="default" style={{ color: 'grey' }}>Select an option</option>
                  <option name="Started">Started</option>
                  <option name="completed">Completed</option>
                </select>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputEmail1">Contact Number</label>
                <input type="text" class="form-control"   value={contactNo} onChange={(e) => setContactNo(e.target.value)} placeholder="Enter Contact Number" readOnly></input>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputEmail1">Gate Number</label>
                <input type="text" class="form-control"   value={gateNo} onChange={(e) => setGateNo(e.target.value)} placeholder="Enter Gate Number"></input>
              </div>

              <div class="form-group">
                <label htmlFor="exampleInputEmail1">PNR Number</label>
                <input type="text" class="form-control"   value={pnrNo} onChange={(e) => setPnrNo(e.target.value)} placeholder="Enter PNR Number"></input>
              </div>

              <div className='subBtn'>
                <button class="btn btn-primary" onClick={handleSubmit}>Submit</button>
                {/* <Link to={'/StaffAvailability'}><button type="submit" class="btn btn-primary" onClick={putData}>Edit</button></Link> */}
              </div>
              
            </form>

      
          
        </div>

      </div>

      <Footer></Footer>

    </>

  )

}
export default UpdateStaffStatus;