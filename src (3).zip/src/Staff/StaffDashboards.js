import React, { Component } from 'react'
import Header from '../Components/Header'
import Footer from '../Components/Footer'
import '../Staff/Staff.css'
import {Link, BrowserRouter, Routes} from 'react-router-dom'

export default class StaffDashboards extends Component {
  render() {
    return (<>
      <Header></Header>
        <div >
          <h2>Staff Dashboard</h2>
          </div>
        <div className='dash'>
        <Link to={"/GetDetails"} onClick={this.create} className="btn btn-success btn-block mb-3">Get Details</Link><br></br>
        <Link to={"/WheelchairStatus"} onClick={this.create} className="btn btn-danger btn-block mb-3">Get Status</Link>
        {/* <Link to={"/GetDetails"} class="btn-btn-danger">Get Details</Link><br></br>
        <Link to={"/WheelchairStatus"} class="btn-btn-danger">Get Status</Link> */}
        </div>
        <Footer></Footer>
        </>
        
      )
  }
}
