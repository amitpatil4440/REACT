import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import axios from 'axios';
// import '../Staff/Staff.css'
import Header from '../Components/Header';
import Footer from '../Components/Footer';
// import '../Components/Footer.css';

class StaffLogin extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: '',
      password: '',
      emailError: '',
      passwordError: '',
      loggedIn: false,
      error: ''
    };
  }

  handleInputChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
  };

  validateForm = () => {
    let isValid = true;
    const { email, password } = this.state;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      this.setState({ emailError: 'Please enter a valid email address.' });
      isValid = false;
    } else {
      this.setState({ emailError: '' });
    }

    if (password.length < 6) {
      this.setState({ passwordError: 'Password must be at least 6 characters long.' });
      isValid = false;
    } else {
      this.setState({ passwordError: '' });
    }

    return isValid;
  };

  handleSubmit = (event) => {
    event.preventDefault();

    if (!this.validateForm()) {
      return;
    }

    const { email, password } = this.state;

    axios
      .post('http://localhost:53678/api/Staff/login', { email, password })
      .then((response) => {

        this.setState({ loggedIn: true });
        alert('Login Successfully...!')
        alert(response.data.email);
      })
      .catch((error) => {
        alert('Invalid Email or Password');
        // this.setState({ error: 'Invalid email or password.' });
      });
  };

  render() {
    const { email, password, emailError, passwordError, loggedIn, error } = this.state;

    if (loggedIn) {
      return window.location = '/StaffDashboard';
    }

    return (
      <>
        <Header></Header>
          {/* <h2>Staff Login</h2> */}
        <div className="cccc11">
        <div className='sss11'></div>
          <div className='a1'>
          {error && <div className="error">{error}</div>}
          <form onSubmit={this.handleSubmit}>

            <div className="form-group">
              <label>Staff Email</label>
              <input type="email" name="email" placeholder="Enter Email" value={email} onChange={this.handleInputChange} className={emailError ? 'form-control is-invalid' : 'form-control'} required />
              {emailError && <div className="invalid-feedback">{emailError}</div>}
            </div>

            <div className="form-group">
              <label>Password</label>
              <input type="password" name="password"  placeholder="Enter Password" value={password} onChange={this.handleInputChange} className={passwordError ? 'form-control is-invalid' : 'form-control'} required />
              {passwordError && <div className="invalid-feedback">{passwordError}</div>}
            </div>

            <button type="submit" className="btn btn-primary">Login</button>
          </form>
          </div>
        </div>
        <Footer></Footer>
      </>
    );
  }
}

export default StaffLogin;