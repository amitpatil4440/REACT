import React, { Component } from 'react'
import axios from 'axios'
import Header from '../Components/Header'
import Footer from '../Components/Footer'

export default class UpdateStatus extends Component {

    constructor(props) {
        super(props)
        this.state = {
            wId: '',
            status: ''
        }

        this.UpdateStatus = this.UpdateStatus.bind(this);
        this.handleChange = this.handleChange.bind(this);

    }

    UpdateStatus() {

        let wId = this.state.wId;
        let url = "http://localhost:53678/api/WheelChair/WheelChairUpdate?WId=" + wId;

        axios.put(url, {
            status: this.state.status

        }).then(response => {

            alert(response.data);
            window.location = '/WheelchairStatus';

        }).catch(error => {

            alert(error);

        });

    }

    handleChange(object) {

        this.setState(object);

    }

    render() {

        return (
            <>
                <Header></Header>
                <div className='wc'>
                <div class="jumbotron">
                        <h1 class="display-4">Update Wheelchair Status</h1>
                        <hr class="my-4"></hr>    
                            
                    </div>
                <div className='cccc'>
                    
                    {/* UpdateStatus */}

                    <form>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Wheeelchair Id</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={(e) => this.handleChange({ wId: e.target.value })} placeholder="Enter wheelchair Id"></input>

                        </div>
                        {/* <div class="form-group">
                            <label for="exampleInputPassword1">Status</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" onChange={(e) => this.handleChange({ status: e.target.value })} placeholder="Select an option"></input>
                        </div> */}

                        <div class="form-group">
                            <label htmlFor="exampleInputEmail1">Status</label>
                            <select onChange={(e) => this.handleChange({ status: e.target.value })} class="form-control">
                                <option name="default" style={{ color: 'grey' }}>Select an option</option>
                                <option name="available">Free</option>
                                <option name="assigned">In Use</option>
                            </select>
                        </div>

                        <button onClick={this.UpdateStatus} class="btn btn-primary">Submit</button>
                    </form>

                </div>
                </div>
                <Footer></Footer>
            </>
        )


    }

}




