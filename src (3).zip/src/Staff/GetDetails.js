import React, { Component } from 'react'
import Header from '../Components/Header';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../Staff/GetDetails.css';

export default class GetDetails extends Component {
    constructor(props) {
        super(props)

        this.state = {

            email: '',
            Details: []
        }
    }

    DisplayAllDetails = () => {
        console.log('hello')
        let email = this.state.email;
        let url = "http://localhost:53678/api/Staff/GetDetailsByEmail?email=" + email;
        axios.get(url).then(resp => {
            //  alert(resp.data);
            console.log(resp.data);
            this.setState({

                Details: resp.data

            });
        }).catch(error => {
            console.warn(error);
        })
    }

    handleChange = (object) => {
        this.setState(object);
    }
    render() {

        const { Details } = this.state;
        return (
            <>

                <Header></Header>

                <div>
                    <label style={{ color: 'black', fontSize: 'large' }}><strong>Enter Your E-Mail </strong></label><br></br>
                    <input style={{ margin: '10px', borderRadius: '5px' }} type="text" name="email" onChange={(e) => this.handleChange({ email: e.target.value })}></input><br></br>
                    <button type="button" onClick={this.DisplayAllDetails}>Search</button>
                    
                    <div class="table-wrapper">
                        <table class="fl-table">
                            <thead>
                                <tr>
                                    <th>Staff Id</th>
                                    <th>Staff Name</th>
                                    <th>Email</th>
                                    <th>Availability Status</th>
                                    <th>Working Status</th>
                                    <th>Contact No</th>
                                    <th>Gate No</th>
                                    <th>PNR No</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>

                                <tr>  
                                    <td>{Details.staffId}</td>
                                    <td>{Details.staffName}</td>
                                    <td>{Details.email}</td>
                                    <td>{Details.availability}</td>
                                    <td>{Details.workingStatus}</td>
                                    <td>{Details.contactNo}</td>
                                    <td>{Details.gateNo}</td>
                                    <td>{Details.pnrNo}</td>
                                    <td><Link to={`/UpdateStaffStatus/${Details.staffId}`}>Update Status</Link></td>


                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <Link to={"/StaffDashboard"} onClick={this.create} className="btn btn-danger btn-block mb-3">Go Back</Link>
                {/* <Link to={"/StaffAvailability"} class="hero-btn">Next Page</Link> */}
            </>

        )

    }
}
