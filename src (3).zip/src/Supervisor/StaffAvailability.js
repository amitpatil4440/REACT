import React, { Component } from 'react'
import Header from '../Components/Header'
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useLoaderData, useParams, withRouter } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';

export default class StaffAvailability extends Component {
    constructor(props) {
        super(props)

        this.state = {
            Availables: [],

        }

    }


    DisplayStaffAvailable() {
        let url = "http://localhost:53678/api/Staff/GetAllStaff";
        axios.get(url).then(resp => {
            // alert(resp.data);
            this.setState({ Availables: resp.data });
        }).catch(error => {
            console.warn(error);
        })

    }
    componentDidMount() {
        this.DisplayStaffAvailable();
    }
    render() {
        const { Availables } = this.state;
        return (
            <>
                <Header></Header>
                <div>
                    {/* <h2 >Staff's Availability Status</h2> */}
                    <div class="jumbotron">
                        <h1 class="display-4">Staff's Status</h1>
                        <hr class="my-4"></hr>
                            <p>To check the new SSR Requests please click following button. </p>
                            <p class="lead">
                                <Link to={"/ViewSSRRequests"} class="btn btn-info">Check</Link>
                            </p>
                    </div>
                    <div class="table-wrapper">
                        <table class="fl-table">
                            <thead>
                                <tr>
                                    <th>Staff Id</th>
                                    <th>Staff Name</th>
                                    <th>Staff Email</th>
                                    <th>Availability</th>
                                    <th>Working Status</th>
                                    <th>Contact Number</th>
                                    <th>Gate Number</th>
                                    <th>PNR Number</th>
                                    <th>Action</th>


                                </tr>
                            </thead>
                            <tbody>
                                {
                                    Availables.map(a =>
                                        <tr>
                                            <td>{a.staffId}</td>
                                            <td>{a.staffName}</td>
                                            <td>{a.email}</td>
                                            {/* <td>{a.password}</td> */}
                                            <td>{a.availability}</td>
                                            <td>{a.workingStatus}</td>
                                            <td>{a.contactNo}</td>
                                            <td>{a.gateNo}</td>
                                            <td>{a.pnrNo}</td>
                                            <td><Link to={"/UpdateStaff/" + a.staffId}>Edit</Link></td>
                                            {/* <td><Link to={`/UpdateStaff/:a.staffId`}>Edit</Link></td> */}
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>

                <Link to={"/SupervisorLogin"} class="btn btn-danger">Logout</Link>

            </>
        )
    }
}


