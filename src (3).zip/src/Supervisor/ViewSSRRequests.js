import React, { Component } from 'react'
import axios from 'axios';
import '../Supervisor/ViewSSRRequests.css';
import Header from '../Components/Header'
import { Link } from 'react-router-dom';
export default class ViewSSRRequests extends Component {
    constructor(props) {
        super(props)

        this.state = {
            Requests: [],
            //    Check:[]
        }
        // this.SearchByPNR=this.SearchByPNR.bind(this);
        // this.handleChange=this.handleChange.bind(this);
    }
    DisplayAllRequests() {
        let url = "http://localhost:53678/api/SSR/GetAllSSRRequest";
        axios.get(url).then(resp => {
            // alert(resp.data);
            this.setState({ Requests: resp.data });
        }).catch(error => {
            console.warn(error);
        })

    }

    
    componentDidMount() {
        this.DisplayAllRequests();
    }
   
    render() {
        const { Requests } = this.state;
        return (
            <>
                <Header></Header>
                <div>
                    <h2>ALL SSR REQUESTS</h2>
                    <div class="table-wrapper">
                        <table class="fl-table">
                            <thead>
                                <tr>
                                    <th>SSR Id</th>
                                    <th>PNR Number</th>
                                    <th>Gate Number</th>


                                </tr>
                            </thead>
                            <tbody>
                                {
                                    Requests.map(a =>
                                        <tr>
                                            <td>{a.ssrId}</td>
                                            <td>{a.pnrNo}</td>
                                            {/* <td><Link to={"/CheckByPNR"}>{a.pnrNo}</Link></td> */}
                                            <td>{a.gateNo}</td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
                
                    <Link to={"/CheckByPNR"} class="btn btn-warning">Passenger Details</Link>
                    <Link to={"/StaffAvailability"} class="btn btn-dark">Available Staff</Link>
                
             </>
        )
    }
}
