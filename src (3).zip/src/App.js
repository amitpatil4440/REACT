
import './App.css';
import { ReactDOM } from 'react';

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Header from './Components/Header';
import Footer from './Components/Footer';
import Home from './Components/Home';
import SupervisorLogin from './Supervisor/SupervisorLogin'
import StaffLogin from './Staff/StaffLogin';
import AboutUs from './Components/AboutUs';
import ContactUs from './Components/ContactUs';
import PassengerLogin from './Passenger/PassengerLogin';
import ViewSSRRequests from './Supervisor/ViewSSRRequests';
import CheckByPNR from './Supervisor/CheckByPNR';
import StaffAvailability from './Supervisor/StaffAvailability';
import UpdateStaff from './Supervisor/UpdateStaff';
import GetDetails from './Staff/GetDetails';
import WheelchairStatus from './Staff/WheelchairStatus';
import UpdateStatus from './Staff/UpdateStatus';
// import {StaffDashboard} from './Staff/StaffDashboard';
import StaffDashboards from './Staff/StaffDashboards';
import UpdateStaffStatus from './Staff/UpdateStaffStatus';
function App() {
  return (
    <div className="App">
      {/* <SupervisorLogin></SupervisorLogin> */}
      {/* <PassengerLogin></PassengerLogin> */}
      {/* <ContactUs></ContactUs> */}
      {/* <BrowserRouter> */}
      {/* <Routes> */}
      {/* <Header></Header> */}
      {/* <Home></Home> */}
      {/* <Footer></Footer> */}
      {/* <AboutUs></AboutUs> */}
      {/* <ContactUs></ContactUs> */}
      {/* <Route path='/AboutUs' element={<AboutUs/>}></Route> */}
      {/* </Routes> */}
      {/* </BrowserRouter> */}
      {/* <ViewSSRRequests></ViewSSRRequests> */}
      

      <BrowserRouter>

 <Routes>

 <Route index element={<Home></Home>} />
 <Route path="/Home" element={<Home></Home>}></Route>
 <Route path="/AboutUs" element={<AboutUs/>}></Route> 
 <Route path="/ContactUs" element={<ContactUs/>}></Route>

 <Route path="/PassengerLogin" element={<PassengerLogin/>}></Route>

 <Route path="/SupervisorLogin" element={<SupervisorLogin/>}></Route>
 <Route path="/ViewSSRRequests" element={<ViewSSRRequests/>}></Route>
 <Route path="/CheckByPNR" element={<CheckByPNR/>}></Route>
 <Route path="/StaffAvailability" element={<StaffAvailability/>}></Route>
 <Route path="/UpdateStaff/:staffId" element={<UpdateStaff/>}></Route>

 <Route path="/StaffLogin" element={<StaffLogin/>}></Route>
 <Route path="/GetDetails" element={<GetDetails/>}></Route>
 <Route path="/WheelchairStatus" element={<WheelchairStatus/>}></Route>
 <Route path="/UpdateStatus" element={<UpdateStatus/>}></Route>
 <Route path="/StaffDashboard" element={<StaffDashboards/>}></Route>
 <Route path="/UpdateStaffStatus/:staffId" element={<UpdateStaffStatus/>}></Route>
  
 </Routes>

 </BrowserRouter>
    </div>
  );
}

export default App;
