import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import Header from '../Components/Header'
import Footer from '../Components/Footer'
import './PassengerLogin.css'
import axios from 'axios';
export default class PassengerLogin extends Component {
  // 
  constructor(props) {
    super(props)

    this.state = {
      pnrNo: '',
      gateNo: ''

    }
    this.submit = this.submit.bind(this);
    // this.BtnSubmit=this.BtnSubmit.bind(this);
    this.handlechange = this.handlechange.bind(this);
  }
  submit() {
    console.log(this.state);
    let url = "http://localhost:53678/api/SSR/SSRRequest";

    axios.post(url, {

      pnrNo: this.state.pnrNo,
      gateNo: parseInt(this.state.gateNo)
      // gateNo:e.target.value;
    }).then(response => {
      if (response.data.pnrNo !== '') {
        alert("Request Submitted Successfully...!");
        sessionStorage.setItem("pnrNo", JSON.stringify(response.data.pnrNo));
        window.location = '/Home';
       
      }
      else {
        alert("Username/password is Invalid");
      }
    }).catch(error => {
      alert(error);
    });
  }
  handlechange(object) {
    this.setState(object);
  }

  render() {
    return (
      <>
        <Header></Header>
        <div className='pass'>
          <div className='ccc1'>
            
              <form>

                <div class="form-group1">
                  <label for="exampleInputEmail1">PNR Number</label>
                  <input type="text" class="form-control" name='pnrNo' onChange={(e) => this.handlechange({ pnrNo: e.target.value })} aria-describedby="emailHelp" placeholder="Enter PNR Number"></input>
                </div>
                <div class="form-group1">
                  <label for="exampleInputPassword1">Gate Number</label>
                  <input type="text" class="form-control" name='gateNo' onChange={(e) => this.handlechange({ gateNo: e.target.value })} placeholder="Enter Gate Number"></input>
                </div>
                <Link to={'/Home'}><button onClick={this.submit} type="submit" class="btn btn-primary">Submit</button></Link>
              </form>
            
          </div>
        </div>
        <Footer></Footer>
      </>
    )
  }
}
