﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;

namespace WRM.Repositories
{
    public interface ISupervisorRepo
    {
        int AddSupervisor(Supervisor supervisor);
        object GetSupervisorByEmail(string email);
        List<Supervisor> GetAllSupervisors();
        LoginSupervisor logIn(LoginSupervisor loginSupervisor);
    }
}
