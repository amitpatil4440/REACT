﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Context;
using WRM.ExceptionHandling;
using WRM.Models;
using WRM.Services;

namespace WRM.Repositories
{
    public class StaffRepo : IStaffRepo
    {
        readonly WrmDbContext _wrmDbContext;
        private readonly ITokenGeneration _tokengeneration;

        public StaffRepo(WrmDbContext wrmDbContext, ITokenGeneration tokenGeneration)
        {
            _wrmDbContext = wrmDbContext;
            _tokengeneration = tokenGeneration;
        }


        public int AddStaff(Staff staff)
        {

            _wrmDbContext.StaffTbl.Add(staff);
            return _wrmDbContext.SaveChanges();
        }
        public List<Staff> GetAllStaff()
        {
            List<Staff> staff = _wrmDbContext.StaffTbl.ToList();
            return staff;
        }

        public Staff GetDetailsByEmail(string email)
        {
            return _wrmDbContext.StaffTbl.Where(s => s.Email == email).FirstOrDefault();
        }

        public async Task<object> GetStaffByEmail(string Email)
        {
            return await _wrmDbContext.StaffTbl.Where(s => s.Email == Email).FirstOrDefaultAsync();
       
            
        }

        public Staff GetStaffById(int staffId)
        {
            return _wrmDbContext.StaffTbl.Where(s => s.StaffId == staffId).FirstOrDefault();
        }

        public LoginStaff logIn(LoginStaff loginStaff)
        {
            var user = _wrmDbContext.StaffTbl.Where(s => s.Email == loginStaff.Email).FirstOrDefault();

            if (user != null)
            {
                if (user.Password != loginStaff.Password) return null;

                loginStaff.Password = user.Password;
                loginStaff.token = _tokengeneration.generatetokenstaff(loginStaff);
                return loginStaff;
            }
            return null;
        }

        public List<Staff> StaffStatusAvailable()
        {
            List<Staff> staff = _wrmDbContext.StaffTbl.Where(s => s.Availability == "Available").ToList();
            return staff;
        }

        public Staff StaffUpdate(int staffId, Staff staff)
        {
            staff.StaffId = staffId;
            _wrmDbContext.Entry(staff).State = EntityState.Modified;
            _wrmDbContext.SaveChanges();
            return staff;
        }

        
    }
}


 