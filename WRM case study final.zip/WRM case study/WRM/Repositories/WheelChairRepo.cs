﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Context;
using WRM.Models;

namespace WRM.Repositories
{
    public class WheelChairRepo : IWheelChairRepo

    {
        readonly WrmDbContext _wrmDbContext;
        public WheelChairRepo(WrmDbContext wrmDbContext)
        {
            _wrmDbContext = wrmDbContext;
        }

        public int addwheelChair(WheelChair wheelchair)
        {
            _wrmDbContext.WheelChairTbl.Add(wheelchair);
            return _wrmDbContext.SaveChanges();

        }

        public List<WheelChair> GetAllWheelChairs()
        {
            List<WheelChair> wheelChairs = _wrmDbContext.WheelChairTbl.ToList();
            return wheelChairs;
        }

        public async Task<WheelChair> GetWheelChairByWId(int wId)
        {
            return await _wrmDbContext.WheelChairTbl.Where(x => x.WId == wId).FirstOrDefaultAsync();
        }

        public WheelChair WheelChairUpdate(int wId, WheelChair wheelChair)
        {
            wheelChair.WId = wId;
            _wrmDbContext.Entry(wheelChair).State = EntityState.Modified;
            _wrmDbContext.SaveChanges();
            return wheelChair;
        }
    }
}

