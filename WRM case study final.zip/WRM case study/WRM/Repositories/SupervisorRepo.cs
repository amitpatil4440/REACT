﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Context;
using WRM.Models;
using WRM.Services;

namespace WRM.Repositories
{
    public class SupervisorRepo:ISupervisorRepo
    {
        readonly WrmDbContext _wrmDbContext;
        private readonly ITokenGeneration _tokenGeneration;

        public SupervisorRepo(WrmDbContext wrmDbContext, ITokenGeneration tokenGeneration)
        {
            _wrmDbContext = wrmDbContext;
            _tokenGeneration = tokenGeneration;
        }

        public int AddSupervisor(Supervisor supervisor)
        {
            _wrmDbContext.SupervisorTbl.Add(supervisor);
            return _wrmDbContext.SaveChanges();
        }

        public List<Supervisor> GetAllSupervisors()
        {
            List<Supervisor> supervisors = _wrmDbContext.SupervisorTbl.ToList();
            return supervisors;
        }

        public object GetSupervisorByEmail(string Email)
        {
            return _wrmDbContext.SupervisorTbl.Where(s => s.Email == Email).FirstOrDefault();
        }

        public LoginSupervisor logIn(LoginSupervisor loginSupervisor)
        {
            var user = _wrmDbContext.SupervisorTbl.Where(s => s.Email == loginSupervisor.Email && s.Password == loginSupervisor.Password).FirstOrDefault();

            if (user != null)
            {
                if (user.Password != loginSupervisor.Password) return null;

                loginSupervisor.Password = user.Password;
                loginSupervisor.token = _tokenGeneration.generatetokensupervisor(loginSupervisor);
                return loginSupervisor;
            }
            return null;
        }
    }
}
