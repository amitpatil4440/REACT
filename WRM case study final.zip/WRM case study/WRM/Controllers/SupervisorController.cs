﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WRM.Models;
using WRM.Services;
using WRM.SRP;

namespace WRM.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [LogFilter]
    public class SupervisorController : ControllerBase
    {
        readonly ISupervisorService _supervisorService;
        public SupervisorController(ISupervisorService supervisorService)
        {
            this._supervisorService = supervisorService;

        }
        [Route("AddSupervisor")]
        [HttpPost]
        public ActionResult AddSupervisor(Supervisor supervisor)
        {
            var status = _supervisorService.AddSupervisor(supervisor);
            return Ok(supervisor);
        }
        [Route("GetAllSupervisors")]
        [HttpGet]
        public ActionResult GetAllSupervisors()
        {
            List<Supervisor> supervisors = _supervisorService.GetAllSupervisors();
            return Ok(supervisors);
         }
        [Route("login")]
        [HttpPost]
        public ActionResult LogIn(LoginSupervisor loginSupervisor)
        {
            LoginSupervisor supervisor = _supervisorService.LogIn(loginSupervisor);
            if (supervisor != null)
                return Ok(supervisor);
            else
                return BadRequest("Invalid Email and Password");
        }
    }
}
