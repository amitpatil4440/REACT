﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Services;
using WRM.SRP;

namespace WRM.Controllers
{
    [ExceptionHandler]
    [Route("api/[controller]")]
    [ApiController]
    [LogFilter]
    
    public class StaffController : ControllerBase
    {
        private readonly IStaffService _staffService;
        private readonly ILog log;
        public StaffController(IStaffService staffService)
        {
            this._staffService = staffService;
            log = LogManager.GetLogger(typeof(StaffController));


        }
        [Route("AddStaff")]
        [HttpPost]
        public async Task<ActionResult> AddStaff(Staff staff)
        {
            var status = await _staffService.AddStaff(staff);
            return Ok(status);
        }




        [Route("GetAllStaff")]
        [HttpGet]
        public ActionResult GetAllStaff()
        {
            List<Staff> staff = _staffService.GetAllStaff();
            return Ok(staff);
        }

        [Route("login")]
        [HttpPost]
        public ActionResult LogIn(LoginStaff loginStaff)
        {
            LoginStaff staff = _staffService.LogIn(loginStaff);
            if (staff != null)
                return Ok(staff);
            else
                return BadRequest("Invalid Email and Password");
     
        }
        [Route("StaffStatusAvailable")]
        [HttpGet]
        public ActionResult StaffStatusAvailabale()
        {
            List<Staff> StaffStatusAvailable = _staffService.StaffStatusAvailable();
            return Ok(StaffStatusAvailable);
        }
        [Route("StaffUpdate")]
        [HttpPut]
        public ActionResult StaffUpdate(int StaffId, Staff staff)
        {
            Staff staff1 = _staffService.StaffUpdate(StaffId, staff);
            return Ok(staff1);
        }
        
        [Route("GetDetailsByEmail")]
        [HttpGet]
        public ActionResult GetDetailsByEmail(string email)
        {
            Staff getStaff = _staffService.GetDetailsByEmail(email);
            if (getStaff == null)
            {
                return BadRequest($"Staff {email} not Found");
            }
            else
            {
                return Ok(getStaff);
            }

        }

        [Route("GetStaffById")]
        [HttpGet]
        public ActionResult GetStaffById(int StaffId)
        {
            Staff getStaff = _staffService.GetStaffById(StaffId);
            if (getStaff == null)
            {
                return BadRequest($"Staff {StaffId} not Found");
            }
            else
            {
                return Ok(getStaff);
            }
        }
    }
}
