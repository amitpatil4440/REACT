﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Services;
using WRM.SRP;

namespace WRM.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class PassengerController : ControllerBase
    {
        readonly IPassengerService _passengerService;
        public PassengerController(IPassengerService passengerService)
        {
            this._passengerService = passengerService;
        }
        [Route("AddPassenger")]
        [HttpPost]
        public async Task<ActionResult> AddPassenger(Passenger passenger)
        {
            try
            {
                var status = await _passengerService.AddPassenger(passenger);
                if (status == true)
                    return Ok(status);
                 
            }
            catch (Exception)
            {
                throw;
            }
            return BadRequest();
            

        }
        [Route("GetAllPassengers")]
        [HttpGet]
        public ActionResult GetAllPassengers()
        {
            List<Passenger> passenger = _passengerService.GetAllPassengers();
            return Ok(passenger);
        }
        [Route("CheckByPNR")]
        [HttpGet]
        public ActionResult CheckByPNR(string PNRNo)
        {
            Passenger passenger = _passengerService.ChechByPNR(PNRNo);
            if (passenger!= null)
            {
                
                return Ok(passenger);
            }
            else
                return Ok("Invalid PNRNo");
            
            

        }

    }

}
