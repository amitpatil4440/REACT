﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WRM.ExceptionHandling
{
    public class PnrNoExistException : ApplicationException
    {
        public PnrNoExistException()
        {
        }
        public PnrNoExistException(string msg) : base(msg)
        {
        }

    }
}
