﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;

namespace WRM.Services
{
    public interface IWheelChairService
    {
        Task<string> AddWheelChair(WheelChair wheelchair);
        WheelChair WheelChairUpdate(int wId, WheelChair wheelChair);
        List<WheelChair> GetAllWheelChairs();
    }
}
