﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Repositories;

namespace WRM.Services
{
    public class WheelChairService : IWheelChairService
    {
        readonly IWheelChairRepo _wheelChairRepo;
        public WheelChairService(IWheelChairRepo wheelChairRepo)
        {
            _wheelChairRepo = wheelChairRepo;

        }

        public async Task<string> AddWheelChair(WheelChair wheelchair)
        {
            WheelChair wheelChairtExists = await _wheelChairRepo.GetWheelChairByWId(wheelchair.WId);
            if (wheelChairtExists == null)
            {
                int a = _wheelChairRepo.addwheelChair(wheelchair);
                if (a == 1)
                {
                    return $"added successfully";
                }
                else
                {
                    return $"unsuccessful";
                }
            }
            else
            {
                return $"unsuccess";
            }

        }

        public List<WheelChair> GetAllWheelChairs()
        {
            List<WheelChair> wheelChairs = _wheelChairRepo.GetAllWheelChairs();
            return wheelChairs;
        }

        public WheelChair WheelChairUpdate(int wId, WheelChair wheelChair)
        {
            WheelChair wheelChair1 = _wheelChairRepo.WheelChairUpdate(wId, wheelChair);
            return wheelChair1;
        }
    }

}

