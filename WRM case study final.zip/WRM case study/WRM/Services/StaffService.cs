﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Repositories;
//using static WRM.Repositories.IStaffRepo;

namespace WRM.Services
{
    public class StaffService: IStaffService
    {
        readonly IStaffRepo _staffRepo;
        readonly ITokenGeneration _tokengeneration;
        public StaffService(IStaffRepo staffRepo, ITokenGeneration tokenGeneration)
        {
            _staffRepo = staffRepo;
            _tokengeneration = tokenGeneration;

        }
        public async Task<string> AddStaff(Staff staff)
        {
            var staffExists = await _staffRepo.GetStaffByEmail(staff.Email);
            if (staffExists == null)
            {
                int a = _staffRepo.AddStaff(staff);
                if (a == 1)
                {
                    return $"added successfully";
                }
                else
                {
                    return $"unsuccessful";
                }
            }
            else
            {
                return $"unsuccess";
            }
        }
        

        

        public List<Staff> GetAllStaff()
        {
            List<Staff> staff = _staffRepo.GetAllStaff();
            return staff;
        }
        public Staff GetDetailsByEmail(string email)
        {
            return _staffRepo.GetDetailsByEmail(email);
        }

        public Staff GetStaffById(int staffId)
        {
            return _staffRepo.GetStaffById(staffId);
        }

        public LoginStaff LogIn(LoginStaff loginStaff)
        {
            LoginStaff staff = _staffRepo.logIn(loginStaff);
            return staff;
        }

        public List<Staff> StaffStatusAvailable()
        {
            List<Staff> staff = _staffRepo.StaffStatusAvailable();
            return staff;
        }
        public Staff StaffUpdate(int staffId, Staff staff)
        {
            Staff staff1 = _staffRepo.StaffUpdate(staffId, staff);
            return staff1;
        }
    }
}
