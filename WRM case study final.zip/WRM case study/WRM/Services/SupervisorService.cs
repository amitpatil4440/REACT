﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Repositories;

namespace WRM.Services
{
    public class SupervisorService: ISupervisorService
    {
        readonly ISupervisorRepo _supervisorRepo;
        public SupervisorService(ISupervisorRepo supervisorRepo)
        {
            _supervisorRepo = supervisorRepo;

        }

        public Supervisor AddSupervisor(Supervisor supervisor)
        {
            var supervisorExists =  _supervisorRepo.GetSupervisorByEmail(supervisor.Email);
            if (supervisorExists == null)
            {
                int a = _supervisorRepo.AddSupervisor(supervisor);
                if (a == 1)
                {
                    return supervisor;
                }
                else
                {
                    return null ;
                }
            }
            else
            {
                return null;
            }

        }

        public List<Supervisor> GetAllSupervisors()
        {
            List<Supervisor> supervisors = _supervisorRepo.GetAllSupervisors();
            return supervisors;
        }

        public LoginSupervisor LogIn(LoginSupervisor loginSupervisor)
        {
            LoginSupervisor supervisor =  _supervisorRepo.logIn(loginSupervisor);
            return supervisor;
        }

         
    }
}
