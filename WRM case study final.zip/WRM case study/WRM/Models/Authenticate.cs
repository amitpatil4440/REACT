﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace WRM.Models
{
    public  static class Authenticate
    {
        public static string GenerateJsonWebToken()
        {
            var securitykey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("280D44AB1E9F79B5CCE2DD4F58F5FE91F0FBACDAC9F7447DFFC318CEB79F2D02"));
            var credentials = new SigningCredentials(securitykey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("UserName", "Admin"),
                new Claim("Role", "1"),
            };
            var token = new JwtSecurityToken("abc", "abc",
                claims,
                DateTime.UtcNow,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);

        }
        //ConfigureJwtAuthentication
        internal static TokenValidationParameters tokenValidationParams;
        public static void ConfigureJwtAuthentication(this IServiceCollection services)
        {
            var securitykey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("280D44AB1E9F79B5CCE2DD4F58F5FE91F0FBACDAC9F7447DFFC318CEB79F2D02"));
            var credentials = new SigningCredentials(securitykey, SecurityAlgorithms.HmacSha256);

            tokenValidationParams = new TokenValidationParameters()
            {
                ValidateIssuerSigningKey = true,
                ValidIssuer = "http://localhost:53678",
                ValidateLifetime = true,
                ValidAudience = "http://localhost:53678",
                ValidateAudience = true,
                RequireSignedTokens = true,
                IssuerSigningKey = credentials.Key,
                ClockSkew = TimeSpan.FromMinutes(30)
            };
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })

                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = tokenValidationParams;
#if PROD || UAT
                    options.InludeErrorDetails = false;
#elif DEBUG
                    options.RequireHttpsMetadata = false;
#endif
                });

        }
    }
}
