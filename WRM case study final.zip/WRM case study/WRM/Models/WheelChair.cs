﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WRM.Models
{
    public class WheelChair
    {
        [Key]
        public int WId{ get; set; }
        public string Status { get; set; }
    }
}
