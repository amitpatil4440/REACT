﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WRM.Migrations
{
    public partial class six : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GateNo",
                table: "PassengerTbl");

            migrationBuilder.AlterColumn<string>(
                name: "ContactNo",
                table: "PassengerTbl",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "ContactNo",
                table: "PassengerTbl",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<int>(
                name: "GateNo",
                table: "PassengerTbl",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
