﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WRM.Migrations
{
    public partial class four : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "pnrno",
                table: "StaffTbl",
                newName: "pnrNo");

            migrationBuilder.RenameColumn(
                name: "gateno",
                table: "StaffTbl",
                newName: "gateNo");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "pnrNo",
                table: "StaffTbl",
                newName: "pnrno");

            migrationBuilder.RenameColumn(
                name: "gateNo",
                table: "StaffTbl",
                newName: "gateno");
        }
    }
}
