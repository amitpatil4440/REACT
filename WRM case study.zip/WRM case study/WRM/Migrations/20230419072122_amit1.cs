﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WRM.Migrations
{
    public partial class amit1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GateNo",
                table: "PassengerTbl");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "GateNo",
                table: "PassengerTbl",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
