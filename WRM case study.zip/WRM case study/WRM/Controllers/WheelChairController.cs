﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Models;
using WRM.Services;

namespace WRM.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WheelChairController : ControllerBase
    {
        private readonly IWheelChairService _wheelChairService;
        public WheelChairController(IWheelChairService wheelChairService)
        {
            this._wheelChairService = wheelChairService;

        }
        [Route("AddWheelChair")]
        [HttpPost]
        public async Task<ActionResult> AddWheelChair(WheelChair wheelChair)
        {
            string status = await _wheelChairService.AddWheelChair(wheelChair);
            return Ok(status);
        }
        [Route("WheelChairUpdate")]
        [HttpPut]
        public ActionResult WheelChairUpdate(int WId,WheelChair wheelChair)
        {
            WheelChair wheelChair1 = _wheelChairService.WheelChairUpdate(WId, wheelChair);
            return Ok(wheelChair1);
        }
        [Route("GetAllWheelChairs")]
        [HttpGet]
        public ActionResult GetAllWheelChairs()
        {
            List<WheelChair> wheelChairs = _wheelChairService.GetAllWheelChairs();
            return Ok(wheelChairs);
        }

    }
}
