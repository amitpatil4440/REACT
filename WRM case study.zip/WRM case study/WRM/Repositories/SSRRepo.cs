﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WRM.Context;
using WRM.ExceptionHandling;
using WRM.Models;

namespace WRM.Repositories
{
    public class SSRRepo: ISSRRepo
    {
       private readonly WrmDbContext _wrmDbContext;
        public SSRRepo(WrmDbContext wrmDbContext)
        {
            this._wrmDbContext = wrmDbContext;
        }

        public List<SSR> GetAllSSRRequest()
        {
            List<SSR> ssr = _wrmDbContext.WRequestTbl.ToList();
            return ssr;
        }

        public SSR SSRRequest(SSR ssr)
        {
            //Passenger s = _wrmDbContext.PassengerTbl.Where(w => w.PNRNo== ssr.PNRNo).FirstOrDefault();
            //if (s != null)
            //{
            //    if (s.PNRNo == ssr.PNRNo)
            //    {
            Passenger status = _wrmDbContext.PassengerTbl.Where(p => p.PNRNo == ssr.PNRNo).FirstOrDefault();
            if (status != null)
            {
                _wrmDbContext.WRequestTbl.Add(ssr);
                _wrmDbContext.SaveChanges();
                return ssr;
            }
            else
            {
                throw new InvalidPNRException("Enter valid PNR number");
            }
            //    }
            //    else
            //    {
            //        return null;
            //    }
            //}
            //else
            //{
            //    return null;
            //}
            

        }
    }
}
